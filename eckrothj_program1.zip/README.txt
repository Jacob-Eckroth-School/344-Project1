To compile the file simply type "make"

To run the files type "./movies fileName" where fileName is the name of the file
you want to execute the program on.
