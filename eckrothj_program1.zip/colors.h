void resetColor();
void printError(char*);
void setRed();
void setGreen();
void setCyan();
